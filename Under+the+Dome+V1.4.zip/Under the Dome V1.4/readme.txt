Made by: DVSDesign.ca

Install Guide:

Make sure to use 1.8.1-pre4 or later


Singleplayer

1-go to: %appdata% > .minecraft > Saves

2-Add "Under the Dome" to you're saves folder

3-Ready to go!


Multiplayer

1-Add to your server

2-rename the folder "world"

3-Make sure Command Blocks = True in server properties


Soundpack

Go to options > ResourePacks > Open ResourcePack folder (in minecraft)

Drag the "Dome SoundPack.zip" into the ResourcePack folder


